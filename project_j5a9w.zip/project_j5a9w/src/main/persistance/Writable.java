package persistance;

import org.json.JSONObject;

//Code influenced by the JsonSerializationDemo: https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo.git
//Represents an interface with a method that creates a JSON object in every class implementing the interface
public interface Writable {
    // EFFECTS: returns this as JSON object
    JSONObject toJson();
}
