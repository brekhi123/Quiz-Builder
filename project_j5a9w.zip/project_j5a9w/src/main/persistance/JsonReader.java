package persistance;

import model.Quiz;
import model.QuizQuestion;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Stream;

// Represents a reader that reads quiz from JSON data stored in file
// Code influenced by the JsonSerializationDemo: https://github.students.cs.ubc.ca/CPSC210/JsonSerializationDemo.git
public class JsonReader {
    private String source;

    //EFFECTS: initiates reader to read from given source file
    public JsonReader(String source) {
        this.source = source;
    }

    //EFFECTS: reads quiz from file and returns it;
    //throws IOException or JSONException if an error occurs reading data from file
    public Quiz read() throws IOException, JSONException {
        String jsonData = readFile(source);
        JSONObject jsonObject = new JSONObject(jsonData);
        return parseQuiz(jsonObject);
    }

    //EFFECTS: reads source file as string and returns it
    private String readFile(String source) throws IOException {
        StringBuilder contentBuilder = new StringBuilder();
        try (Stream<String> stream = Files.lines(Paths.get(source), StandardCharsets.UTF_8)) {
            stream.forEach(s -> contentBuilder.append(s));
        }
        return contentBuilder.toString();
    }

    //EFFECTS: parses quiz from JSON object and returns it
    private Quiz parseQuiz(JSONObject jsonObject) {
        String title = jsonObject.getString("Title");
        Quiz q = new Quiz(title);
        addQuestions(q, jsonObject);
        return q;
    }

    //MODIFIES: q
    //EFFECTS: parses questions from JSON object and adds them to quiz
    private void addQuestions(Quiz q, JSONObject jsonObject) {
        JSONArray jsonArray = jsonObject.getJSONArray("Questions");
        for (Object json : jsonArray) {
            JSONObject nextQuestion = (JSONObject) json;
            addQuestion(q, nextQuestion);
        }
    }

    //MODIFIES: q
    //EFFECTS: parses question from JSON object and adds it to quiz
    private void addQuestion(Quiz q, JSONObject jsonObject) {
        String name = jsonObject.getString("Text");
        JSONArray options = (JSONArray) jsonObject.get("Options");
        String[] optionsFinal = makeJsonStringArr(options);
        int correctOption = jsonObject.getInt("Correct option Index");
        QuizQuestion qq = new QuizQuestion(name, optionsFinal, correctOption);
        q.addQuestion(qq);
    }

    //EFFECTS: converts a JSONArray to a StringArray with length 3
    private String[] makeJsonStringArr(JSONArray options) {
        String[] stringArr = new String[3];
        stringArr[0] = options.getString(0);
        stringArr[1] = options.getString(1);
        stringArr[2] = options.getString(2);
        return stringArr;
    }

}

