package ui;

import model.Event;
import model.EventLog;
import model.Quiz;
import model.QuizQuestion;
import org.json.JSONException;
import persistance.JsonReader;
import persistance.JsonWriter;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;

public class GUI extends JFrame implements ActionListener {
    private JsonReader jsonReader;
    private JsonWriter jsonWriter;
    private JMenuBar menuBar;
    private JMenu menu;
    private JMenuItem save;
    private JMenuItem load;

    private JFrame frame;
    private ArrayList<QuizQuestion> questions;
    private JTextField questionField;
    private JTextField[] optionsFields;
    private JTextField correctOptionField;
    private JPanel panel;
    private JButton addButton;
    private JButton viewButton;
    private JPanel buttonPanel;
    private JPanel questionPanel;
    private JButton submitButton;
    private ButtonGroup group;
    private ArrayList<ButtonGroup> groups;
    private int correctInd;
    private boolean submitted = false;
    private ArrayList<QuizQuestion> incorrect;
    private int score = 0;

    private ImageIcon image;
    private Image scaled;
    private JLabel imageLabel;
    private Quiz quiz = new Quiz("");

    public GUI() throws FileNotFoundException {
        initializeFrame();
        createMenuBar();
        createLayout();
        initializeButtons();
    }

    public void initializeFrame() {
        groups = new ArrayList<>();
        frame = new JFrame();
        questions = new ArrayList<>();
        jsonWriter = new JsonWriter("./data/quiz.json");
        jsonReader = new JsonReader("./data/quiz.json");
        frame.setTitle("Quiz Builder Application");
        frame.setSize(600, 500);  // Adjusted size for better spacing
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                printLog();
            }
        });
    }

    public void createMenuBar() {
        menuBar = new JMenuBar();
        menu = new JMenu("File");
        save = new JMenuItem("Save");
        load = new JMenuItem("Load");
        save.addActionListener(this::saveQuiz);
        load.addActionListener(this::loadQuiz);
        menu.add(save);
        menu.add(load);
        menuBar.add(menu);
        frame.setJMenuBar(menuBar);
    }

    public void createLayout() {
        panel = new JPanel(new GridLayout(6, 3));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));  // Added padding
        questionField = new JTextField();
        panel.add(new JLabel("Question:"));
        panel.add(questionField);

        optionsFields = new JTextField[3];
        for (int i = 0; i < 3; i++) {
            optionsFields[i] = new JTextField();
            panel.add(new JLabel("Option " + (i + 1) + ":"));
            panel.add(optionsFields[i]);
        }

        correctOptionField = new JTextField();
        panel.add(new JLabel("Correct Option Index (0-2): "));
        panel.add(correctOptionField);

        frame.add(panel, BorderLayout.CENTER);
    }

    public void initializeButtons() {
        addButton = new JButton("Add Question");
        addButton.addActionListener(this);

        viewButton = new JButton("View Questions");
        viewButton.addActionListener(this::viewQuestions);

        buttonPanel = new JPanel();
        buttonPanel.add(addButton);
        buttonPanel.add(viewButton);

        frame.add(buttonPanel, BorderLayout.SOUTH);

        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
    }

    public void saveQuiz(ActionEvent e) {
        try {
            jsonWriter.open();
            Quiz quiz = new Quiz("");
            for (QuizQuestion q : questions) {
                quiz.addQuestion(q);
            }
            jsonWriter.write(quiz);
            jsonWriter.close();
            JOptionPane.showMessageDialog(frame, "Quiz Saved Successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (FileNotFoundException ex) {
            JOptionPane.showMessageDialog(frame, "Unable to save quiz.", "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public void loadQuiz(ActionEvent e) {
        try {
            Quiz quiz = jsonReader.read();
            questions.clear();
            questions.addAll(quiz.getQuestions());
            JOptionPane.showMessageDialog(frame, "Quiz Loaded Successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (JSONException ex) {
            JOptionPane.showMessageDialog(frame, "The Quiz is empty. Please add and save questions.",
                    "Error", JOptionPane.ERROR_MESSAGE);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(frame, "Unable to read file.",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String questionText = questionField.getText();
        String[] optionsText = new String[3];
        for (int i = 0; i < 3; i++) {
            optionsText[i] = optionsFields[i].getText();
        }

        String correctOptionText = correctOptionField.getText();

        if (questionText.isEmpty() || optionsText[0].isEmpty() || optionsText[1].isEmpty() || optionsText[2].isEmpty() || correctOptionText.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please fill out all fields.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            correctInd = Integer.parseInt(correctOptionText);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Please enter a valid number for Correct Option Index.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (correctInd < 0 || correctInd > 2) {
            JOptionPane.showMessageDialog(frame, "Correct Option Index should be between 0 and 2.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        questions.add(new QuizQuestion(questionText, optionsText, correctInd));

        questionField.setText("");
        for (JTextField field : optionsFields) {
            field.setText("");
        }
        correctOptionField.setText("");
    }

    private void viewQuestions(ActionEvent e) {
        if (questions.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please add questions before viewing.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        frame.getContentPane().removeAll();
        questionPanel = new JPanel();
        questionPanel.setLayout(new BoxLayout(questionPanel, BoxLayout.Y_AXIS));
        JScrollPane sp = new JScrollPane(questionPanel);

        for (QuizQuestion q : this.questions) {
            group = new ButtonGroup();

            JLabel questionText = new JLabel(q.getText());
            questionText.setFont(new Font("Arial", Font.BOLD, 16));  // Adjusted font size
            questionPanel.add(questionText);

            addRadioButton(q.getOptions()[0], group);
            addRadioButton(q.getOptions()[1], group);
            addRadioButton(q.getOptions()[2], group);

            groups.add(group);
        }

        submitButton = new JButton("Submit");
        submitButton.addActionListener(this::computeScore);
        frame.add(submitButton, BorderLayout.SOUTH);
        frame.add(sp, BorderLayout.CENTER);

        frame.revalidate();
        frame.repaint();
    }

    private void addRadioButton(String option, ButtonGroup group) {
        JRadioButton radioButton = new JRadioButton(option);
        radioButton.setFont(new Font("Arial", Font.PLAIN, 14));  // Adjusted font size
        group.add(radioButton);
        questionPanel.add(radioButton);
    }

    private void computeScore(ActionEvent e) {
        if (submitted) {
            return;
        }

        if (questions.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please add questions before submitting.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        questionPanel.removeAll();
        incorrect = new ArrayList<>();
        submitButton.setVisible(false);

        for (int i = 0; i < this.questions.size(); i++) {
            QuizQuestion q = this.questions.get(i);
            ButtonGroup bg = groups.get(i);
            int selected = getSelectedButton(bg);

            if (selected == q.getCorrectOptionIndex()) {
                score++;
                quiz.increaseScore();
            } else {
                incorrect.add(q);
            }
        }

        submitted = true;
        initializeImage();
        JButton resultsButton = new JButton("Results");
        resultsButton.addActionListener(this::viewResults);

        frame.add(resultsButton, BorderLayout.SOUTH);
        updateComponents();
    }

    private void initializeImage() {
        image = new ImageIcon("./data/submitted.jpeg");
        scaled = image.getImage().getScaledInstance(350, 300, Image.SCALE_SMOOTH);
        imageLabel = new JLabel(new ImageIcon(scaled));

        JPanel imagePanel = new JPanel();
        imagePanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        imagePanel.add(imageLabel);

        questionPanel.add(imagePanel);
    }

    private void updateComponents() {
        frame.revalidate();
        frame.repaint();
        questionPanel.revalidate();
        questionPanel.repaint();
    }

    private void viewResults(ActionEvent e) {
        questionPanel.removeAll();
        JLabel scoreMessage = new JLabel("Score: " + score);
        scoreMessage.setFont(new Font("Arial", Font.BOLD, 20));  // Adjusted font size
        questionPanel.add(scoreMessage);

        for (QuizQuestion q : incorrect) {
            JLabel incorrectMessage = new JLabel(q.getText() + " is incorrect. The correct answer is " + q.getOptions()[q.getCorrectOptionIndex()] + ".");
            incorrectMessage.setFont(new Font("Arial", Font.PLAIN, 14));  // Adjusted font size
            questionPanel.add(incorrectMessage);
            quiz.addToIncorrectQuestions(q);
        }

        questionPanel.revalidate();
        questionPanel.repaint();
    }

    private void printLog() {
        EventLog el = EventLog.getInstance();
        for (Event e : el) {
            System.out.println(e.toString() + "\n\n");
        }
    }

    private int getSelectedButton(ButtonGroup buttonGroup) {
        int id = 0;
        Enumeration<AbstractButton> buttons = buttonGroup.getElements();
        while (buttons.hasMoreElements()) {
            AbstractButton button = buttons.nextElement();
            if (button.isSelected()) {
                return id;
            }
            id++;
        }
        return -1;
    }
}
