package ui;

import model.Quiz;
import model.QuizQuestion;
import model.User;
import org.json.JSONException;
import persistance.JsonReader;
import persistance.JsonWriter;

import javax.swing.*;
import java.awt.*;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;

// Quiz Builder Application
public class QuizConsoleNew1 {
    private static final String SAVED_QUIZ = "./data/quiz.json";
    private JsonWriter jsonWriter;
    private JsonReader jsonReader;
    private Scanner scanner;
    private Quiz quiz;
    private Character userChoice;
    private User user;
    private long startTime;
    private long endTime;
//    private JPanel panel;
//    private JFrame frame;
//    private JPanel panel;

    // EFFECTS: Runs the login application
    public QuizConsoleNew1() throws FileNotFoundException {
        jsonWriter = new JsonWriter(SAVED_QUIZ);
        jsonReader = new JsonReader(SAVED_QUIZ);
//        panel = new JPanel((LayoutManager) quiz);
//        frame = new JFrame();
////        frame.setContentPane(new QuizConsoleNew1().panel);
//        frame.setTitle("Quiz Builder");
//        frame.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
//        frame.setSize(600, 500);
//        frame.setVisible(true);
//        frame.setResizable(false);
//        frame.setLocationRelativeTo(null);
        login();
    }

//    // GUI
//    public void guI() {
//        JFrame frame = new JFrame();
//        JPanel panel = new JPanel();
//        panel.setBorder(BorderFactory.createEmptyBorder(30,30,10,30));
//        panel.setLayout(new GridLayout(0, 1));
//
//        frame.add(panel, BorderLayout.CENTER);
//        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        frame.setTitle("Our GUI");
//        frame.pack();
//        frame.setVisible(true);
//
//    }

    // MODIFIES: this
    // EFFECTS: processes user input by confirming the username and password
    private void login() {
//        JButton buttonYes = new JButton("Yes");
//        JButton buttonNo = new JButton("No");
//        panel = new JPanel();
//        panel.setBorder(BorderFactory.createEmptyBorder(30,30,10,30));
//        panel.setLayout(new GridLayout(0, 1));
//        panel.add(buttonYes);
//        panel.add(buttonNo);
//        frame.add(panel, BorderLayout.CENTER);
//        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        frame.setTitle("Our GUI");
//        frame.pack();
//        frame.setVisible(true);


        user = new User("", "");
        scanner = new Scanner(System.in);
        printFirstStatements();
        System.out.println("Please log in now: ");
        System.out.print("Username: ");
        String userLogin = scanner.nextLine();
        System.out.print("Password: ");
        String pass = scanner.nextLine();
        if (user.getUsername().equals(userLogin) && user.getPassword().equals(pass)) {
            System.out.println("Login successful!, Would you like to load the previous questions to this quiz?");
            String answerLoad = scanner.nextLine();
            if (answerLoad.equals("yes") || answerLoad.equals("Yes")) {
                loadQuestions();
                createLoadedQuiz();
            } else {
                createQuiz();
            }
        } else {
            System.out.println("Login failed. Please check your username and password.");
        }
    }

    //EFFECTS: prints out several statements in order for user interaction
    private void printFirstStatements() {
        System.out.println("Welcome to the " + "Quiz Builder" + "!");
        System.out.println("Please create an account:");
        System.out.print("Username: ");
        String username = scanner.nextLine();
        user.setUsername(username);
        System.out.print("Password: ");
        String password = scanner.nextLine();
        user.setPassword(password);
    }

    //MODIFIES: this
    //EFFECTS: processes user input for creating questions on quiz
    private void createQuiz() {
        quiz = new Quiz("");
        System.out.println("What would you like to name this quiz? ");
        quiz.setTitle(scanner.nextLine() + " Quiz");
        System.out.println("How many questions do you want to add? ");
        int times = scanner.nextInt();
        scanner.nextLine();
        for (int q = 0; q < times; q++) {
            System.out.println("Please add the question: ");
            String questionNew = scanner.nextLine();
            System.out.println("Please add three options for the question: ");
            String[] options = new String[3];
            System.out.print("A: ");
            options[0] = scanner.next();
            System.out.print("B: ");
            options[1] = scanner.next();
            System.out.print("C: ");
            options[2] = scanner.next();
            System.out.println("Please enter the correct answer option (A/B/C): ");
            Character correctOption = scanner.next().charAt(0);
            quiz.addQuestion(new QuizQuestion(questionNew, options, quiz.getOptionIndex(correctOption)));
            scanner.nextLine();
        }
        initQuiz();
    }

    //MODIFIES: this
    //EFFECTS: processes user input for creating questions on quiz
    private void createLoadedQuiz() {
        System.out.println("How many questions do you want to add to this existing quiz? ");
        int times = scanner.nextInt();
        scanner.nextLine();
        for (int q = 0; q < times; q++) {
            System.out.println("Please add the question: ");
            String questionNew = scanner.nextLine();
            System.out.println("Please add three options for the question: ");
            String[] options = new String[3];
            System.out.print("A: ");
            options[0] = scanner.next();
            System.out.print("B: ");
            options[1] = scanner.next();
            System.out.print("C: ");
            options[2] = scanner.next();
            System.out.println("Please enter the correct answer option (A/B/C): ");
            Character correctOption = scanner.next().charAt(0);
            quiz.addQuestion(new QuizQuestion(questionNew, options, quiz.getOptionIndex(correctOption)));
            scanner.nextLine();
        }
        initQuiz();
    }

    //MODIFIES: this
    //EFFECTS: processes user input and starts quiz based on user input
    private void initQuiz() {
        System.out.println("Do you want to save the quiz?");
        String answerSave = scanner.nextLine();
        if (answerSave.equals("yes") || answerSave.equals("Yes")) {
            saveQuestions();
        }
        System.out.println("Do you want to view and take the quiz now?");
        String answer = scanner.nextLine();
        if (answer.equals("yes") || answer.equals("Yes")) {
            runQuiz();
        } else {
            System.out.println("Thank you for using the Quiz Builder App!");
        }
    }

    //MODIFIES: this
    //EFFECTS: processes user input to start and complete the quiz
    private void runQuiz() {
        startTime = System.currentTimeMillis();
        System.out.println(quiz.getTitle());
        for (QuizQuestion question : quiz.getQuestions()) {
            System.out.println("Question: " + question.getText());
            for (int i = 0; i < question.getOptions().length; i++) {
                if (i == 0) {
                    System.out.println('A' + ") " + question.getOptions()[i]);
                }
                if (i == 1) {
                    System.out.println('B' + ") " + question.getOptions()[i]);
                }
                if (i == 2) {
                    System.out.println('C' + ") " + question.getOptions()[i]);
                }
            }
            System.out.print("Pick one-of (A/B/C): ");
            userChoice = scanner.next().charAt(0);
            checkAnswer(question);
        }
        completeQuiz();
    }

    //MODIFIES: this
    //EFFECTS: increases score if user answer is correct
    private void checkAnswer(QuizQuestion question1) {
        int selectedOptionIndex = quiz.getOptionIndex(userChoice);
        if (question1.isCorrect(selectedOptionIndex)) {
            System.out.println("Correct!\n");
            quiz.increaseScore();
        } else {
            System.out.println("Incorrect. ");
            quiz.addToIncorrectQuestions(question1);
        }
    }

    //EFFECTS: prints the score, time taken to do the quiz and incorrectly answered questions
    private void completeQuiz() {
        endTime = System.currentTimeMillis();
        System.out.println("Quiz complete! Your score: " + quiz.getScore() + "/"
                + quiz.getQuestions().size());
        System.out.println("Quiz completed in: " + (endTime - startTime) / 1000 + " Seconds");

        for (QuizQuestion inc : quiz.getIncorrectQuestions()) {
            System.out.println("For the question: " + inc.getText() + " " + "," + " The correct answer was: "
                    + inc.getOptions()[inc.getCorrectOptionIndex()]);
        }
    }

    //EFFECTS: saves the questions to file
    public void saveQuestions() {
        try {
            jsonWriter.open();
            jsonWriter.write(quiz);
            jsonWriter.close();
            System.out.println("Saved " + quiz.getTitle() + " to " + SAVED_QUIZ);
        } catch (FileNotFoundException e) {
            System.out.println("Unable to write to file: " + SAVED_QUIZ);
        }
    }

    // MODIFIES: this
    // EFFECTS: loads questions from file
    private void loadQuestions() {
        try {
            quiz = jsonReader.read();
            System.out.println("Loaded questions of: " + quiz.getTitle() + " from " + SAVED_QUIZ);
        } catch (IOException e) {
            System.out.println("Unable to read from file: " + SAVED_QUIZ);
        } catch (JSONException e) {
            System.out.println("Unable to load from file: " + SAVED_QUIZ);
            System.out.println("Please make a new quiz: ");
            createQuiz();
            System.exit(0);
        }
    }
}



