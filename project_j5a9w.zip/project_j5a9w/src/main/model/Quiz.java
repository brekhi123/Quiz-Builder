package model;

import org.json.JSONArray;
import org.json.JSONObject;
import persistance.Writable;
import java.util.ArrayList;
import java.util.List;

//Represents a quiz having a title, list of questions, score and
public class Quiz implements Writable {

    private String title;
    private List<QuizQuestion> questions;
    private int score;
    private List<QuizQuestion> incorrectQuestions;

    //REQUIRES: title is a non-empty String
    //EFFECTS: creates a quiz with the given title, with no questions in it, with a score of zero,
    //          and with no incorrectly answered questions
    public Quiz(String title) {
        this.title = title;
        this.questions = new ArrayList<>();
        this.score = 0;
        this.incorrectQuestions = new ArrayList<>();
    }

    public List<QuizQuestion> getQuestions() {
        return this.questions;
    }

    public void setQuestions(List<QuizQuestion> questions) {
        this.questions = questions;
    }

    //EFFECTS: adds the given question onto the list of questions in the quiz
    public void addQuestion(QuizQuestion question) {
        this.questions.add(question);
//        EventLog.getInstance().logEvent(new Event("Question has been added to quiz!"));

    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    //EFFECTS: gets the index of the option according to the character
    public int getOptionIndex(Character o) {
        if (o.equals('A') || o.equals('a')) {
            return 0;
        } else if (o.equals('B') || o.equals('b')) {
            return 1;
        } else {
            return 2;
        }
    }

    //EFFECTS: increments the score by 1
    public void increaseScore() {
        this.score++;
        EventLog.getInstance().logEvent(new Event("Score has been increased!"));
    }

    public int getScore() {
        return this.score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public List<QuizQuestion> getIncorrectQuestions() {
        return this.incorrectQuestions;
    }

    public void setIncorrectQuestions(List<QuizQuestion> incorrectQuestions) {
        this.incorrectQuestions = incorrectQuestions;
    }

    public void addToIncorrectQuestions(QuizQuestion incQuestion) {
        this.incorrectQuestions.add(incQuestion);
        EventLog.getInstance().logEvent(new Event("Incorrect question has been displayed onto the quiz!"));
    }

    //MODIFIES: json
    //EFFECTS: returns a JSONObject with the elements of the quiz and assigns keys to them
    @Override
    public JSONObject toJson() {
        JSONObject json = new JSONObject();
        json.put("Title", title);
        json.put("Questions", questionsToJson());
        return json;
    }

    //EFFECTS: returns questions in this quiz as a JSON array
    private JSONArray questionsToJson() {
        JSONArray jsonArray = new JSONArray();

        for (QuizQuestion qq : questions) {
            jsonArray.put(qq.toJson());
        }
        return jsonArray;
    }
}



