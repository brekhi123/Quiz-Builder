package model;

import org.json.JSONObject;
import persistance.Writable;

//Represents a quiz question having a title, a list of options and the index of the current option
public class QuizQuestion implements Writable {
    private String text;
    private String[] options;
    private int correctOptionIndex;

    //REQUIRES: question is a non-empty String,
    //options has a length of 3,
    //0 <= correctOptionIndex <= 2,
    //EFFECTS: text of question is set, options are assigned,
    //and index of answer is assigned to the question object
    public QuizQuestion(String text, String[] options, int correctOptionIndex) {
        this.text = text;
        this.options = options;
        this.correctOptionIndex = correctOptionIndex;
        EventLog.getInstance().logEvent(new Event("Question has been added to quiz!."));
    }

    //REQUIRES: 0 <= correctOptionIndex <= 2
    //EFFECTS: returns true if the selectedOptionIndex equals to the correctOptionIndex, false otherwise
    public boolean isCorrect(int selectedOptionIndex) {
        return selectedOptionIndex == correctOptionIndex;
    }

    public String getText() {
//        EventLog.getInstance().logEvent(new Event("Quiz has started. Viewed Question!"));
        return text;

    }

    public void setText(String text) {
        this.text = text;
    }

    public String[] getOptions() {
        return this.options;
    }
    
    public void setOptions(String[] options) {
        this.options = options;
    }

    public int getCorrectOptionIndex() {
        return this.correctOptionIndex;
    }
    
    public void setCorrectOptionIndex(int cop) {
        this.correctOptionIndex = cop;
    }

    //MODIFIES: json
    //EFFECTS: returns a JSONObject with the elements of the quiz with their corresponding keys
    @Override
    public JSONObject toJson() {
        JSONObject json = new JSONObject();
        json.put("Text", text);
        json.put("Correct option Index", correctOptionIndex);
        json.put("Options", options);
        return json;
    }
}


