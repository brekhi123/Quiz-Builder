# Multiple Choice Quiz Maker

## Purpose:

<p> This application enables users to create custom multiple-choice quizzes to assess their comprehension and enhance their knowledge. Users have the freedom to define quiz questions and options. Additionally, each question is assigned an index which points to the position of the correct option in the options list. Once the user finalizes their quiz questions, they can attempt the quiz. After submitting their results, incorrectly answered questions will be highlighted to help users identify their areas of weakness. The application also provides the score and time taken to complete the quiz for the user to track their learning. </p>

## Application/Uses:
<p> This quiz application is suitable for a wide range of users, including students from various academic disciplines, especially those enrolled in courses that emphasize active recall. Students can boost their confidence and improve their academic performance by regularly assessing their understanding at different stages of their learning journey. Additionally, educators such as teachers and professors can use this application to create customized quizzes, offering students a valuable learning resource. </p>

## Interest in the project:
<p> I am personally interested in this project because I've often struggled with finding effective study methods, particularly when it comes to active recall. Some courses like Biology or Chemistry, while not conceptually challenging, often involve complex terminology that can be time-consuming to understand. Therefore, this application has the potential to simplify the process of comprehending fundamental aspects of a course, including definitions, vocabulary, and concepts, which can serve as the building blocks for a deeper understanding of the course content. </p>

## User Stories:
-  <em> As a user, I want to be able to add a question to my list of questions, specify its options, and specify its answer.</em>
-  <em> As a user, I want to be able to view the questions already created on my list of questions.</em>
- <em> As a user, I want to be able to attempt the quiz that I created, see the time taken and the view the score achieved on the quiz. </em>
- <em> As a user, I want to see the quiz's incorrectly answered questions with its right answers after the attempt. </em>
- <em> As a user, when I start the quiz creation, I want to be given the option to load the quiz from file and start adding questions to the loaded quiz.</em>
- <em> As a user, after constructing a quiz , I want to be given the option to save the quiz and its questions to file.</em>

## Instructions for Grader

- You can generate the first required action related to the user story "adding multiple Xs to a Y" by filling in the required fields for a question and then pressing the "Add Question" button.
- You can generate the second required action related to the user story "adding multiple Xs to a Y" by viewing the questions that were added by pressing the "View Questions" button. Once that button is pressed, after answering the questions created, press the "Submit" button and then the "Results" button. After pressing the results button, the questions that were answered incorrectly will be shown along with the score.
- You can locate my visual component by adding a question using the "Add Question" button and then the "View Questions" button. After answering the questions and pressing the "Submit" button, the visual component will be displayed.
- You can save the state of my application by adding a question using the "Add Question" button, choosing "File" from the menu bar on the top left of the frame. Then, after pressing the "Save" button in the bar, that question will be saved.
- You can reload the state of my application by clicking "File" from the top left corner of the frame and then clicking the "Load" button.

## Phase 4: Task 2
- Mon Nov 27 21:34:24 PST 2023 Question has been added to quiz!.
- Mon Nov 27 21:34:28 PST 2023 Question has been added to quiz!.
- Mon Nov 27 21:34:32 PST 2023 Score has been increased!
- Mon Nov 27 21:34:32 PST 2023 Incorrect question has been displayed onto the quiz!

## Phase 4: Task 3
- If more time was given for the project, I would have refactored the code by using more methods from my model package since I had come to the realization that there was redundancy in the effects of the methods that I had used in the GUI/UI and the methods that were already created in my model. I feel that this would have made the code much shorter and would have yielded a more of a systematic approach towards programming. Another way to refactor the code is to have all the GUI-related logic and quiz be in separate classes so it is easier to handle/understand and even test the code.