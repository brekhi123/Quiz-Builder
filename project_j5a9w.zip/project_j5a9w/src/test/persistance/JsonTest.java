package persistance;

import model.QuizQuestion;

import static org.junit.jupiter.api.Assertions.*;

public class JsonTest {

    protected void checkQuestion(String text, String[] options, int coi, QuizQuestion question) {
        assertEquals(text, question.getText());
        assertEquals(options[0], question.getOptions()[0]);
        assertEquals(options[1], question.getOptions()[1]);
        assertEquals(options[2], question.getOptions()[2]);
        assertArrayEquals(options, question.getOptions());
        assertEquals(coi, question.getCorrectOptionIndex());
    }

}
