package persistance;

import model.Quiz;
import model.QuizQuestion;
import org.json.JSONException;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class JsonReaderTest extends JsonTest {

    @Test
    void testReaderNonExistentFile() {
        JsonReader reader = new JsonReader("./data/noSuchFile.json");
        try {
            Quiz q = reader.read();
            fail("IOException expected");
        } catch (IOException e) {
            // pass
        }
    }

    @Test
    void testReaderCompletelyEmptyQuiz() {
        JsonReader reader = new JsonReader("./data/testReaderGeneralQuizCompletelyEmpty.json");
        try {
            Quiz q = reader.read();
            fail("JSONException expected");
        } catch (IOException e) {
            fail("Couldn't read from file");
        } catch (JSONException e) {
           // pass
        }
    }

    @Test
    void testReaderEmptyQuizWithNoQuestions() {
        JsonReader reader = new JsonReader("./data/testReaderEmptyQuiz.json");
        try {
            Quiz q = reader.read();
            List<QuizQuestion> questions = q.getQuestions();
            assertEquals("Hello Quiz", q.getTitle());
            assertEquals(0, questions.size());
        } catch (IOException e) {
            fail("Couldn't read from file");
        } catch (JSONException e) {
            fail("Couldn't read from an empty file");
        }
    }

    @Test
    void testReaderGeneralQuiz() {
        JsonReader reader = new JsonReader("./data/testReaderGeneralQuiz.json");
        try {
            Quiz q = reader.read();
            assertEquals("Hello Quiz", q.getTitle());
            List<QuizQuestion> questions = q.getQuestions();
            assertEquals(3, questions.size());
            checkQuestion("rr", new String[]{"3", "4", "5"}, 0, questions.get(0));

            checkQuestion("tt", new String[]{"4", "5", "6"}, 2, questions.get(1));

            checkQuestion("pp", new String[]{"4", "5", "6"}, 1, questions.get(2));
        } catch (IOException e) {
            fail("Couldn't read from file");
        } catch (JSONException e) {
            fail("Couldn't read from an empty file");
        }

    }
}
