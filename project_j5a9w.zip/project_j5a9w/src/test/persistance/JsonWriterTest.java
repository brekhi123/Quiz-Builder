package persistance;

import model.Quiz;
import model.QuizQuestion;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

class JsonWriterTest extends JsonTest {

    @Test
    void testWriterInvalidFile() {
        try {
            Quiz q = new Quiz("Test Quiz");
            JsonWriter writer = new JsonWriter("./data/my\0illegal:fileName.json");
            writer.open();
            fail("IOException was expected");
        } catch (IOException e) {
            // pass
        }
    }

    @Test
    void testWriterEmptyQuiz() {
        try {
            Quiz q = new Quiz("Test Quiz");
            JsonWriter writer = new JsonWriter("./data/testWriterEmptyQuiz.json");
            writer.open();
            writer.write(q);
            writer.close();

            JsonReader reader = new JsonReader("./data/testWriterEmptyQuiz.json");
            q = reader.read();
            assertEquals("Test Quiz", q.getTitle());
            List<QuizQuestion> questions = q.getQuestions();
            assertEquals(0, questions.size());
        } catch (IOException e) {
            fail("Exception should not have been thrown");
        }
    }

    @Test
    void testWriterGeneralQuizWithOneQuestion() {
        try {
            Quiz q = new Quiz("Test Quiz 2");
            q.addQuestion(new QuizQuestion("Test Question",new String[]{"2", "3", "4"}, 0));
            JsonWriter writer = new JsonWriter("./data/testWriterGeneralQuizWithOneQuestion.json");
            writer.open();
            writer.write(q);
            writer.close();

            JsonReader reader = new JsonReader("./data/testWriterGeneralQuizWithOneQuestion.json");
            q = reader.read();
            assertEquals("Test Quiz 2", q.getTitle());
            List<QuizQuestion> questions = q.getQuestions();
            assertEquals(1, questions.size());
            checkQuestion("Test Question", new String[]{"2", "3", "4"},0, questions.get(0));

        } catch (IOException e) {
            fail("Exception should not have been thrown");
        }
    }

    @Test
    void testWriterGeneralQuizWithMoreQuestions() {
        try {
            Quiz q = new Quiz("Test Quiz 3");
            q.addQuestion(new QuizQuestion("Test Question 1",new String[]{"1", "2", "3"}, 0));
            q.addQuestion(new QuizQuestion("Test Question 2",new String[]{"4", "5", "6"}, 2));
            q.addQuestion(new QuizQuestion("Test Question 3",new String[]{"7", "8", "9"}, 1));
            JsonWriter writer = new JsonWriter("./data/testWriterGeneralQuizWithMoreQuestions.json");
            writer.open();
            writer.write(q);
            writer.close();

            JsonReader reader = new JsonReader("./data/testWriterGeneralQuizWithMoreQuestions.json");
            q = reader.read();
            assertEquals("Test Quiz 3", q.getTitle());
            List<QuizQuestion> questions = q.getQuestions();
            assertEquals(3, questions.size());
            checkQuestion("Test Question 1", new String[]{"1", "2", "3"},0, questions.get(0));
            checkQuestion("Test Question 2", new String[]{"4", "5", "6"},2, questions.get(1));
            checkQuestion("Test Question 3", new String[]{"7", "8", "9"},1, questions.get(2));

        } catch (IOException e) {
            fail("Exception should not have been thrown");
        }
    }
}