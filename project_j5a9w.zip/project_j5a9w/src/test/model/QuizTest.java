package model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class QuizTest {
    private Quiz quiz1;
    private List<QuizQuestion> questions;
    private List<QuizQuestion> incQuestions;
    private QuizQuestion q1;
    private QuizQuestion q2;
    private QuizQuestion q3;



    @BeforeEach
    void setUp() {
        quiz1 = new Quiz("Quiz 1");

        q1 = new QuizQuestion("How tall is Vancouver Lookout?",(new String[]{"500", "400", "300"})
                ,0);

        q2 = new QuizQuestion("What is the capital of Canada?",
                (new String[]{"India", "Ottawa", "NewZealand"}),1);

        q3 = new QuizQuestion("What is 9 + 10?",
                (new String[]{"19", "33", "21"}),2);
    }

    @Test
    public void testConstructor() {
        assertEquals(quiz1.getTitle(), "Quiz 1");
        questions = quiz1.getQuestions();
        incQuestions = quiz1.getIncorrectQuestions();
        assertTrue(incQuestions.isEmpty());
        assertTrue(questions.isEmpty());
        assertEquals(quiz1.getScore(),0);
    }

    @Test
    public void testAddQuestionOnce() {
        quiz1.addQuestion(q1);
        questions = quiz1.getQuestions();
        assertEquals(questions.size(), 1);
        assertEquals(questions.get(0), q1);

    }

    @Test
    public void testAddQuestionMoreThanOnce() {
        quiz1.addQuestion(q1);
        quiz1.addQuestion(q2);
        quiz1.addQuestion(q3);
        questions = quiz1.getQuestions();
        assertEquals(questions.size(), 3);
        assertEquals(questions.get(0), q1);
        assertEquals(questions.get(1), q2);
        assertEquals(questions.get(2), q3);
    }

    @Test
    public void testGetOptionIndex() {
        assertEquals(quiz1.getOptionIndex('A'), 0);
        assertEquals(quiz1.getOptionIndex('B'), 1);
        assertEquals(quiz1.getOptionIndex('C'), 2);
        assertEquals(quiz1.getOptionIndex('a'), 0);
        assertEquals(quiz1.getOptionIndex('b'), 1);
        assertEquals(quiz1.getOptionIndex('c'), 2);
    }

    @Test
    public void testAddToIncorrectQuestionsOnce() {
        q1.setCorrectOptionIndex(1);
        assertFalse(q1.isCorrect(0));
        quiz1.addToIncorrectQuestions(q1);
        incQuestions = quiz1.getIncorrectQuestions();
        assertEquals(incQuestions.size(), 1);
        assertEquals(incQuestions.get(0), q1);
    }

    @Test
    public void testAddToIncorrectQuestionsMoreThanOnce() {
        q1.setCorrectOptionIndex(1);
        assertFalse(q1.isCorrect(0));
        quiz1.addToIncorrectQuestions(q1);
        q2.setCorrectOptionIndex(2);
        assertFalse(q2.isCorrect(1));
        quiz1.addToIncorrectQuestions(q2);
        incQuestions = quiz1.getIncorrectQuestions();
        assertEquals(incQuestions.size(), 2);
        assertEquals(incQuestions.get(0), q1);
        assertEquals(incQuestions.get(1), q2);
    }

    @Test
    public void testAddToIncorrectQuestionsWithVariability() {
        q1.setCorrectOptionIndex(1);
        assertFalse(q1.isCorrect(0));
        quiz1.addToIncorrectQuestions(q1);
        q2.setCorrectOptionIndex(2);
        assertTrue(q2.isCorrect(2));
        quiz1.increaseScore();
        assertFalse(q3.isCorrect(0));
        quiz1.addToIncorrectQuestions(q3);
        incQuestions = quiz1.getIncorrectQuestions();
        assertEquals(incQuestions.size(), 2);
        assertEquals(incQuestions.get(0), q1);
        assertEquals(incQuestions.get(1), q3);
        assertEquals(quiz1.getScore(), 1);
    }

    @Test
    public void testMiniQuizSimulation() {
        quiz1.setTitle("Mini Quiz");
        quiz1.setQuestions(List.of(q2, q3));
        quiz1.setScore(2);
        assertTrue(q2.isCorrect(1));
        quiz1.increaseScore();
        assertFalse(q3.isCorrect(0));
        assertFalse(q1.isCorrect(1));
        quiz1.setIncorrectQuestions((List.of(q3, q1)));
        incQuestions = quiz1.getIncorrectQuestions();
        assertEquals(quiz1.getScore(), 3);
        assertEquals(incQuestions.size(), 2);
        assertEquals(incQuestions.get(0), q3);
        assertEquals(incQuestions.get(1), q1);
        assertEquals(quiz1.getTitle(), "Mini Quiz");
    }

    @Test
    public void testMiniQuizSimulationWithAllRight() {
        quiz1.addQuestion(q1);
        quiz1.addQuestion(q2);
        quiz1.addQuestion(q3);
        assertTrue(q1.isCorrect(0));
        quiz1.increaseScore();
        assertTrue(q2.isCorrect(1));
        quiz1.increaseScore();
        assertTrue(q3.isCorrect(2));
        quiz1.increaseScore();
        questions = quiz1.getQuestions();
        assertEquals(questions.size(), 3);
        assertEquals(questions.get(0), q1);
        assertEquals(questions.get(1), q2);
        assertEquals(questions.get(2), q3);
        assertEquals(quiz1.getScore(), 3);
        incQuestions = quiz1.getIncorrectQuestions();
        assertTrue(incQuestions.isEmpty());
    }

    @Test
    public void testMiniQuizSimulationWithOneWrong() {
        quiz1.addQuestion(q1);
        quiz1.addQuestion(q2);
        quiz1.addQuestion(q3);
        assertTrue(q1.isCorrect(0));
        quiz1.increaseScore();
        assertFalse(q2.isCorrect(2));
        assertTrue(q3.isCorrect(2));
        quiz1.increaseScore();
        questions = quiz1.getQuestions();
        assertEquals(questions.size(), 3);
        assertEquals(questions.get(0), q1);
        assertEquals(questions.get(1), q2);
        assertEquals(questions.get(2), q3);
        assertEquals(quiz1.getScore(), 2);
        quiz1.addToIncorrectQuestions(q2);
        incQuestions = quiz1.getIncorrectQuestions();
        assertEquals(incQuestions.size(), 1);
        assertEquals(incQuestions.get(0), q2);
    }

    @Test
    public void testMiniQuizSimulationWithAllWrong() {
        quiz1.setTitle("New Quiz1");
        quiz1.addQuestion(q1);
        quiz1.addQuestion(q2);
        quiz1.addQuestion(q3);
        assertFalse(q1.isCorrect(1));
        assertFalse(q2.isCorrect(2));
        assertFalse(q3.isCorrect(1));
        questions = quiz1.getQuestions();
        assertEquals(questions.size(), 3);
        assertEquals(questions.get(0), q1);
        assertEquals(questions.get(1), q2);
        assertEquals(questions.get(2), q3);
        assertEquals(quiz1.getScore(), 0);
        quiz1.addToIncorrectQuestions(q1);
        quiz1.addToIncorrectQuestions(q2);
        quiz1.addToIncorrectQuestions(q3);
        incQuestions = quiz1.getIncorrectQuestions();
        assertEquals(incQuestions.size(), 3);
        assertEquals(incQuestions.get(0), q1);
        assertEquals(incQuestions.get(1), q2);
        assertEquals(incQuestions.get(2), q3);
        assertEquals(quiz1.getTitle(), "New Quiz1");
    }
}