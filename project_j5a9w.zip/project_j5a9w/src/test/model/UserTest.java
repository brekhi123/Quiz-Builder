package model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class UserTest {
    private User user;

    @BeforeEach
    void setUp() {
        user = new User("B", "B");
    }

    @Test
    public void testConstructor() {
        user.setUsername("CPSC-210");
        user.setPassword("CODE");
        assertEquals(user.getUsername(), "CPSC-210");
        assertEquals(user.getPassword(), "CODE");
    }

    @Test
    public void testChangeUsernameAndPasswordOnce() {
        user.setUsername("Hello");
        user.setPassword("World");
        assertEquals(user.getUsername(), "Hello");
        assertEquals(user.getPassword(), "World");
    }

    @Test
    public void testChangeUsernameAndPasswordMoreThanOnce() {
        user.setUsername("Hello");
        user.setPassword("World");
        assertEquals(user.getUsername(), "Hello");
        assertEquals(user.getPassword(), "World");
        user.setUsername("Dark");
        user.setPassword("Knight");
        assertEquals(user.getUsername(), "Dark");
        assertEquals(user.getPassword(), "Knight");
    }
}



