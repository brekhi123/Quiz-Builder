package model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class QuizQuestionTest {
    private QuizQuestion q1;
    private QuizQuestion q2;
    private QuizQuestion q3;
    private String[] options;

    @BeforeEach
    void setUp() {
        q1 = new QuizQuestion("How tall is Vancouver Lookout?",(new String[]{"500", "400", "300"})
                ,0);

        q2 = new QuizQuestion("What is the capital of Canada?",
                (new String[]{"India", "Ottawa", "NewZealand"}),1);

        q3 = new QuizQuestion("What is 9 + 10?",
                (new String[]{"19", "33", "21"}),2);

    }

    @Test
    public void testConstructor() {

        options = q1.getOptions();
        assertEquals(q1.getText(), "How tall is Vancouver Lookout?");
        assertEquals(options[0], "500");
        assertEquals(options[1], "400");
        assertEquals(options[2], "300");
        assertEquals(options.length, 3);
        assertEquals(q1.getCorrectOptionIndex(),0);
    }

    @Test
    public void testConstructorAgain() {
        options = q2.getOptions();
        assertEquals(q2.getText(), "What is the capital of Canada?");
        assertEquals(options[0], "India");
        assertEquals(options[1], "Ottawa");
        assertEquals(options[2], "NewZealand");
        assertEquals(options.length, 3);
        assertEquals(q2.getCorrectOptionIndex(),1);
    }

    @Test
    public void testConstructorWithSetMethods() {
        q3.setText("What is 9 + 10 (Its not that easy)");
        q3.setOptions((new String[]{"19888", "3443", "21"}));
        q3.setCorrectOptionIndex(3);
        options = q3.getOptions();
        assertEquals(q3.getText(), "What is 9 + 10 (Its not that easy)");
        assertEquals(options[0], "19888");
        assertEquals(options[1], "3443");
        assertEquals(options[2], "21");
        assertEquals(options.length, 3);
        assertEquals(q3.getCorrectOptionIndex(),3);
    }

    @Test
    public void testIsCorrectWithIndexOfZero() {
        assertTrue(q1.isCorrect(0));
        assertFalse(q1.isCorrect(1));
        assertFalse(q1.isCorrect(2));
    }

    @Test
    public void testIsCorrectWithIndexOfOne() {
        assertTrue(q2.isCorrect(1));
        assertFalse(q2.isCorrect(0));
        assertFalse(q2.isCorrect(2));
    }

    @Test
    public void testIsCorrectWithIndexOfTwo() {
        assertTrue(q3.isCorrect(2));
        assertFalse(q3.isCorrect(0));
        assertFalse(q3.isCorrect(1));
    }

    @Test
    public void testIsCorrectWithAllCorrect() {
        assertTrue(q1.isCorrect(0));
        assertTrue(q2.isCorrect(1));
        assertTrue(q3.isCorrect(2));
    }

    @Test
    public void testIsCorrectWithOneCorrect() {
        assertFalse(q1.isCorrect(2));
        assertTrue(q2.isCorrect(1));
        assertFalse(q3.isCorrect(1));
    }

    @Test
    public void testIsCorrectWithAllWrong() {
        assertFalse(q1.isCorrect(1));
        assertFalse(q2.isCorrect(2));
        assertFalse(q3.isCorrect(0));
    }

    @Test
    public void testChangingInfoOfQuestion() {
        q1.setText("What is 4/2?");
        q1.setOptions((new String[]{"3", "1", "2"}));
        q1.setCorrectOptionIndex(2);
        options = q1.getOptions();
        assertEquals(q1.getText(), "What is 4/2?");
        assertEquals(options[0], "3");
        assertEquals(options[1], "1");
        assertEquals(options[2], "2");
        assertEquals(options.length, 3);
        assertEquals(q1.getCorrectOptionIndex(),2);
        assertTrue(q1.isCorrect(2));
    }
}
